package com.springboot.pjt1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pjt1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
