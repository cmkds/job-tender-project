package com.springboot.pjt1.data.dto;

import lombok.Data;

@Data
public class MachineLocationDTO {
    long locSeq;
    String city;
    String name;
}
