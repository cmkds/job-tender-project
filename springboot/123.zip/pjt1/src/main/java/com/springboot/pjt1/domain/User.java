package com.springboot.pjt1.domain;

import lombok.Data;

import java.io.Serializable;

@Data
public class User implements Serializable {

}
