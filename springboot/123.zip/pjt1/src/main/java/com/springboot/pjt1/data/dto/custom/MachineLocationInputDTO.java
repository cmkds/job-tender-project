package com.springboot.pjt1.data.dto.custom;

import lombok.Data;

@Data
public class MachineLocationInputDTO {
    long machineLocationSeq;
    String city;
    String name;
}
