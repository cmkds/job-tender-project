package com.springboot.pjt1.data.dto;

public enum Role {
    ROLE_USER;
}
