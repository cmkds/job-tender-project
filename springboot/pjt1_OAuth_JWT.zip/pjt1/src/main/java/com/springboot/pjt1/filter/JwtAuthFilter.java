package com.springboot.pjt1.filter;

import com.springboot.pjt1.data.dto.MemberDTO;
import com.springboot.pjt1.service.TokenService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Arrays;

// API 요청 헤더에 전달되는 JWT 유효성 인증
@RequiredArgsConstructor
public class JwtAuthFilter extends GenericFilterBean {
    private final TokenService tokenService;
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        System.out.println("do filter start");
        String token = ((HttpServletRequest)request).getHeader("Auth");
        System.out.println("token " + token);

        // 토큰 존재 여부 && 유효성 검사
        if (token != null && tokenService.verifyToken(token)) {
            String email = tokenService.getUid(token);
            String name = tokenService.getName(token);

            System.out.println("Email " + email);
            System.out.println("Name " + name);

            // DB연동을 안했으니 이메일 정보로 유저를 만들어주겠습니다
            MemberDTO memberDTO = MemberDTO.builder()
                    .email(email)
                    .name(name).build();

            Authentication auth = getAuthentication(memberDTO);
            SecurityContextHolder.getContext().setAuthentication(auth);
        }

        //chain.doFilter(request, response);
        System.out.println("do filter end");
    }

    public Authentication getAuthentication(MemberDTO member) {
        return new UsernamePasswordAuthenticationToken(member, "",
                Arrays.asList(new SimpleGrantedAuthority("ROLE_USER")));
    }
}