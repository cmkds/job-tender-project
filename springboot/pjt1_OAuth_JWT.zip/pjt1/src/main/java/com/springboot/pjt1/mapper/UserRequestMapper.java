package com.springboot.pjt1.mapper;

import com.springboot.pjt1.data.dto.MemberDTO;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Component;

@Component
public class UserRequestMapper {
    public MemberDTO toDto(OAuth2User oAuth2User) {

        var attributes = oAuth2User.getAttributes();
        return MemberDTO.builder()
                .name((String) attributes.get("name"))
                .email((String) attributes.get("email"))
                .build();
    }
}
