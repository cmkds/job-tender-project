package com.springboot.pjt1.service;

import com.springboot.pjt1.data.entity.Token;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.Base64;
import java.util.Date;

@Service
public class TokenService{
    private String secretKey = "a502_token_secret_key";

    @PostConstruct
    protected void init() {
        secretKey = Base64.getEncoder().encodeToString(secretKey.getBytes());
    }


    public Token generateToken(String uid, String name, String role) {
        long tokenPeriod = 1000L * 60L * 10L;
        long refreshPeriod = 1000L * 60L * 60L * 24L * 30L * 3L;
        this.init();

        Claims claims = Jwts.claims().setSubject(uid);
        claims.put("role", role);
        claims.setExpiration(new Date(System.currentTimeMillis() + tokenPeriod));

        return new Token(
                Jwts.builder().setHeaderParam("Auth", "Auth")
                        .claim("name", name)
                        .claim("email", uid)
                        .claim("role", role)
                        .setExpiration(new Date(System.currentTimeMillis() + tokenPeriod))
                        .signWith(SignatureAlgorithm.HS256, secretKey.getBytes())
                        .compact(),
                Jwts.builder().setHeaderParam("Auth", "Auth")
                        .setSubject(uid)
                        .claim("name", name)
                        .claim("email", uid)
                        .claim("role", role)
                        .setExpiration(new Date(System.currentTimeMillis() + refreshPeriod))
                        .signWith(SignatureAlgorithm.HS256, secretKey.getBytes())
                        .compact());

//        return new Token(
//                "accesstoken",
//                "refreshToken");
    }


    public boolean verifyToken(String token) {
        try {
            System.out.println(secretKey);
            Jws<Claims> claims = Jwts.parser()
                    .setSigningKey(secretKey)
                    .parseClaimsJws(token);
            return claims.getBody()
                    .getExpiration()
                    .after(new Date());
        } catch (Exception e) {
            return false;
        }
    }


    public String getUid(String token) {
        //return Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody().getSubject();
        return (String)Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody().get("email");
    }

    public String getName(String token) {
        return (String)Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody().get("name");
    }
}