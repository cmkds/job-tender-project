package com.springboot.pjt1.config;

import com.springboot.pjt1.filter.JwtAuthFilter;
import com.springboot.pjt1.handler.OAuth2SuccessHandler;
import com.springboot.pjt1.service.CustomOAuth2UserService;
import com.springboot.pjt1.service.TokenService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@RequiredArgsConstructor
@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {
    private final CustomOAuth2UserService oAuth2UserService;
    private final OAuth2SuccessHandler successHandler;
    private final TokenService tokenService;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        System.out.println("configure start");
        http.httpBasic().disable()
                .csrf().disable()
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .authorizeRequests() // 시큐리티 처리에 HttpServletRequest를 이용한다는 것
                .antMatchers("/token/**").permitAll() // 특정 리소스에 권한 설정 -> 인증 절차 없이 허용
                .anyRequest().authenticated() // 나머지 리소스는 인증해야 한다는 의미
                .and()
                .logout().logoutSuccessUrl("/")
                .and()
                // 지정된 필터 앞에 커스텀 필터 추가
                // JwtAuthFilter : API 요청 헤더에 전달되는 JWT 유효성 인증
                .addFilterBefore(new JwtAuthFilter(tokenService), UsernamePasswordAuthenticationFilter.class) // JwtAuthFilter가 User.. 보다 먼저 실행
                .oauth2Login()// oauth2login 설정을 시작
                .loginPage("/login")// login 페이지 url을 직접 설정
                .successHandler(successHandler)// 로그인 성공 시 handler 설정. 토큰 발행 (2)
                .userInfoEndpoint() // oauth2 로그인 성공 후 설정을 시작
                .userService(oAuth2UserService); // oAuth2UserService에서 처리. 로그인 성공시 작업을 진행. 성공 정보를 바탕으로 유저 생성. loadUser (1)
                //.logout().logoutSuccessUrl("/")

        //http.addFilterBefore(new JwtAuthFilter(tokenService), UsernamePasswordAuthenticationFilter.class);
        System.out.println("configure end");
    }
}