package com.springboot.pjt1.data.dto;

import lombok.Data;

@Data
public class MachineLocationDTO {
    long machineLocationSeq;
    String city;
    String name;
}
